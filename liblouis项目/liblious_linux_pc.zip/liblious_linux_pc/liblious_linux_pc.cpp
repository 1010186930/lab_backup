#include "liblious_linux_pc.h"
#include "config.h"
#include "internal.h"
#include<iostream>

using namespace std;
Liblious_linux_pc::Liblious_linux_pc()
{
}
void Liblious_linux_pc::simple_test()
{
    cout<<"777"<<endl;
}
