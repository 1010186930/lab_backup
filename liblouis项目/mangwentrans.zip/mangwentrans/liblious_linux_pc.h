#ifndef LIBLIOUS_LINUX_PC_H
#define LIBLIOUS_LINUX_PC_H

#include "liblious_linux_pc_global.h"

class LIBLIOUS_LINUX_PC_EXPORT Liblious_linux_pc
{
public:
    Liblious_linux_pc();
    void simple_test();
};

#endif // LIBLIOUS_LINUX_PC_H
